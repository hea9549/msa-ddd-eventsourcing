package com.itchain.samplemsa.samplemsa.common;


public interface EventRepository {
    void save(Event event);
    <T extends Aggregate>T load(String id,T t);
}
